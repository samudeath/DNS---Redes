package br.edu.ifg.interf;

public class Constant {
	
	public static final String RMI_ID = "DNS_Server";
	public static final int RMI_PORT = 1099;

}
